var recordData = [
 {
  "length": 1758,
  "seq_id": "004639",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
