var recordData = [
 {
  "length": 1707,
  "seq_id": "002428",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
